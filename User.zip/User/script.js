const container = document.querySelector(".container");
const userButton = document.querySelector(".user-button");
const cartButton = document.querySelector(".cart-button");
const viewProfileButton = document.querySelector("#view-user-profile");
const userLogOutButton = document.querySelector("#user-log-out");
const userMenu = document.querySelector(".user-infor-menu");
const passwordToggleButtons = document.querySelectorAll(".password-toggle-button");
const toUserLoginPageButtons = document.querySelectorAll(".to-user-login");
const toUserSignupPageButtons = document.querySelectorAll(".to-user-signup");
const userInforButton = document.querySelector(".user-infor");
const toCartButton = document.querySelectorAll(".cart-button");
userButton.addEventListener("click", () => {
  changeVisibility(userMenu);
})
toUserLoginPageButtons.forEach((button) => {
  button.addEventListener("click", () => {
    window.location.href = "/User/U02-userLogin/userLogin.html";
  });
});
toUserSignupPageButtons.forEach((button) => {
  button.addEventListener("click", () => {
    window.location.href = "/User/U03-userSignup/userSignup.html";
  });
});
userLogOutButton.addEventListener("click", () => {
   window.location.href = "/User/U01-homePage(Unlogged In)/homePage.html";
})
passwordToggleButtons.forEach((button) => {
  button.addEventListener("click", function () {
    password = this.parentNode.querySelector("input");
    console.log(this.parentNode);
    if (password.type === "password") {
      password.type = "text";
      button.className = "fas fa-eye password-toggle-button";
    } else {
      password.type = "password";
      button.className = "fas fa-eye-slash  password-toggle-button";
    }
  });
});
function changeVisibility(element) {
  var currentVisibility = element.style.visibility;
  if (currentVisibility == "visible") {
    element.style.visibility= "hidden";
  } else {
    element.style.visibility = "visible";
  }
}
viewProfileButton.addEventListener("click", () => {
  window.location.href = ("/User/U06-userProfile/userProfile.html");
}
)