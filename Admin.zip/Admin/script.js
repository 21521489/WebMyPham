const sidebar = document.querySelector(".sidebar");
const sidebarClose = document.querySelector("#sidebar-close");
const menu = document.querySelector(".menu-content");
const actionsButton = document.querySelectorAll(".actions-button");
const deleteButtons = document.querySelectorAll(".delete-button");
const sortingButtons = document.querySelectorAll(".sorting");
sidebarClose.addEventListener("click", () => sidebar.classList.toggle("close"));

function clearPlaceHolder(inputElement){
  inputElement.placeholder = "";
}
function changePasswordVisibility(){
  password = document.getElementById('password-input');
  toggleButton = document.getElementById('toggle-button');
  if (password.type === "password") {
      password.type = "text";
      toggleButton.className = "fas fa-eye";
  }
  else {
      password.type = "password";
      toggleButton.className = "fas fa-eye-slash";
  }
}
actionsButton.forEach((button)=>{
  button.addEventListener("click", () => {
      actionsSubmenu = button.parentNode.querySelector('ul');
      changeVisibility(actionsSubmenu);
  })
})
sortingButtons.forEach((button) => {
  button.addEventListener("click", () => {
    sortUp = button.querySelector(".fa-sort-up");
    sortDown = button.querySelector(".fa-sort-down");
    if (!sortUp.classList.contains("toggle-actived")&&!sortDown.classList.contains("toggle-actived")){
      sortUp.classList.add("toggle-actived");
      sortingButtons.forEach((otherButton) => {
        if (otherButton !== button) {
          const activedOne = otherButton.querySelector(".toggle-actived");
          if (activedOne){
            activedOne.classList.remove("toggle-actived");
          }
        }
      });
    }
    else{
      if (sortUp.classList.contains("toggle-actived")){
        sortUp.classList.remove("toggle-actived");
        sortDown.classList.add("toggle-actived");
      }
      else{
        sortUp.classList.add("toggle-actived");
        sortDown.classList.remove("toggle-actived");
      }
    }
  })
})
deleteButtons.forEach((button) => {
  button.addEventListener("click", () => {
    deletedRow = button.parentNode;
    const result = confirm("Are you sure you want to delete this row?");
    if (result) {
      deletedRow = button.closest("tr");
      deletedRow.remove();
    } else {
    }
  });
});

const addproductbtn=document.querySelector('#addproduct-form');
addproductbtn.addEventListener("click", function(){
  document.querySelector('.addproduct-form').style.display="flex"
})
const addproductclose=document.querySelector('#addproduct-close')
addproductclose.addEventListener("click", function(){
  document.querySelector('.addproduct-form').style.display="none"
})

const adduserbtn=document.querySelector('#adduser-form')
adduserbtn.addEventListener("click", function(){
  document.querySelector('.adduser-form').style.display="flex"
})
const adduserclose=document.querySelector('#adduser-close')
adduserclose.addEventListener("click", function(){
  document.querySelector('.adduser-form').style.display="none"
})
function changeVisibility(element) {
    var currentVisibility = element.style.visibility;
    if (currentVisibility === 'visible') {
        element.style.visibility = 'hidden';
    } else {
        element.style.visibility = 'visible';
    }
}
