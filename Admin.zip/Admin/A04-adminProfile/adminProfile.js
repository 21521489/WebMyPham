const forms = document.querySelectorAll("form");
const toggleButtons = document.querySelectorAll(".toggle-button");
const viewMode = document.querySelector("#view-mode");
const editMode = document.querySelector("#edit-mode");
function clearPlaceHolder(inputElement){
    inputElement.placeholder = "";
}
toggleButtons.forEach((button) => {
    button.addEventListener("click" , ()=>{
        input = button.parentNode.querySelector("input");
        if (input.type === "password") {
            input.type = "text";
            button.className = "fas fa-eye  toggle-button";
        }
        else {
            input.type = "password";
            button.className = "fas fa-eye-slash  toggle-button";
        }  
    })
})
function disbleForm(){
    forms.forEach((form) =>{
        inputElements = form.querySelectorAll("input");
        inputElements.forEach((element) => {
            element.disabled = true;
            element.style.pointerEvents = "none";
         })
     })
     editMode.classList.remove("actived");
     viewMode.classList.add("actived");
 }
function ableForm(){
    forms.forEach((form) =>{
        inputElements = form.querySelectorAll("input");
        inputElements.forEach((element) => {
            element.disabled = false;
            element.style.pointerEvents = "";
         })
     })
     viewMode.classList.remove("actived");
     editMode.classList.add("actived");
}
$(document).ready(function(){
    $("input").each(function(){
        this.disabled = true;
    })
})
